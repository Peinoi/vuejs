import "./assets/main.css";

import { createApp } from "vue";
import App from "./views/TodoCart.vue";

createApp(App).mount("#app");
